import React, { useState, useEffect, useMemo } from 'react';
import {
  QrCode,
  ShoppingBag,
  Sparkles,
  Truck,
  ShieldCheck,
  Clock,
  MapPin,
  Phone,
  Search,
  CheckCircle2,
  Filter,
  Share2,
} from 'lucide-react';
import { ShopInfo, Product, CartItem, Order, ViewMode, OwnerTab, Category } from './types';
import { INITIAL_SHOP_INFO, INITIAL_PRODUCTS, INITIAL_ORDERS, INITIAL_CATEGORIES } from './data/initialData';
import { CustomerHeader } from './components/CustomerHeader';
import { CustomerScannerModal } from './components/CustomerScannerModal';
import { ShopIdentificationBanner } from './components/ShopIdentificationBanner';
import { ProductCard } from './components/ProductCard';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { CustomerOrdersModal } from './components/CustomerOrdersModal';
import { OwnerDashboard } from './components/OwnerDashboard';
import { getShopUrl, shareShopQRCode } from './utils/qrHelper';
import { api } from './services/api';

export default function App() {
  // Load initial state from localStorage cache or fallback
  const [shop, setShop] = useState<ShopInfo>(() => {
    try {
      const saved = localStorage.getItem('apna_mart_shop_info');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_SHOP_INFO;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const saved = localStorage.getItem('apna_mart_categories');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_CATEGORIES;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('apna_mart_products');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_PRODUCTS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('apna_mart_orders');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_ORDERS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('apna_mart_cart');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  // Load persistent cloud data on startup
  useEffect(() => {
    let isMounted = true;
    async function loadCloudData() {
      try {
        const [cloudShop, cloudCats, cloudProds, cloudOrders] = await Promise.all([
          api.getShop().catch(() => null),
          api.getCategories().catch(() => null),
          api.getProducts().catch(() => null),
          api.getOrders().catch(() => null),
        ]);

        if (!isMounted) return;

        if (cloudShop) {
          setShop(cloudShop);
          localStorage.setItem('apna_mart_shop_info', JSON.stringify(cloudShop));
        }
        if (cloudCats && cloudCats.length > 0) {
          setCategories(cloudCats);
          localStorage.setItem('apna_mart_categories', JSON.stringify(cloudCats));
        }
        if (cloudProds && cloudProds.length > 0) {
          setProducts(cloudProds);
          localStorage.setItem('apna_mart_products', JSON.stringify(cloudProds));
        }
        if (cloudOrders) {
          setOrders(cloudOrders);
          localStorage.setItem('apna_mart_orders', JSON.stringify(cloudOrders));
        }
      } catch (err) {
        console.warn('Backend database loading note:', err);
      }
    }

    loadCloudData();
    return () => {
      isMounted = false;
    };
  }, []);

  // Navigation & Modal states
  const [viewMode, setViewMode] = useState<ViewMode>('customer');
  const [ownerInitialTab, setOwnerInitialTab] = useState<OwnerTab>('qr_code');
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [showIdentifiedBanner, setShowIdentifiedBanner] = useState(false);
  const [bannerShopName, setBannerShopName] = useState('');

  // Search & Category Filters
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Persist state updates to localStorage as offline safety net
  useEffect(() => {
    try {
      localStorage.setItem('apna_mart_shop_info', JSON.stringify(shop));
    } catch {}
  }, [shop]);

  useEffect(() => {
    try {
      localStorage.setItem('apna_mart_categories', JSON.stringify(categories));
    } catch {}
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem('apna_mart_products', JSON.stringify(products));
    } catch {}
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('apna_mart_orders', JSON.stringify(orders));
    } catch {}
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem('apna_mart_cart', JSON.stringify(cart));
    } catch {}
  }, [cart]);

  // Check URL parameters for QR scan link (?shop=...)
  useEffect(() => {
    if (typeof window === 'undefined') return;

    try {
      const params = new URLSearchParams(window.location.search);
      const urlShopId = params.get('shop') || params.get('shopId');

      if (urlShopId) {
        // Automatically identify this shop and open Home page
        setViewMode('customer');
        setBannerShopName(shop.name);
        setShowIdentifiedBanner(true);
      }
    } catch (e) {
      console.error('Error parsing shop URL parameter:', e);
    }
  }, [shop.name]);

  // Handle QR code detection from customer scanner
  const handleShopIdentifiedFromQR = (scannedShopId: string, identifiedName: string) => {
    setViewMode('customer');
    setBannerShopName(identifiedName || shop.name);
    setShowIdentifiedBanner(true);
    // Smooth scroll to top of product catalog
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handlePlaceOrder = (newOrder: Order, updatedProducts?: Product[]) => {
    setOrders((prev) => [newOrder, ...prev]);
    if (updatedProducts && updatedProducts.length > 0) {
      setProducts(updatedProducts);
    }
  };

  // Cart totals
  const totalCartCount = useMemo(
    () => cart.reduce((sum, item) => sum + item.quantity, 0),
    [cart]
  );

  const cartTotalAmount = useMemo(
    () => cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
    [cart]
  );

  // Filter products by category and search
  const categoryNames = useMemo(() => {
    const list = ['All'];
    categories.forEach((c) => {
      if (!list.includes(c.name)) list.push(c.name);
    });
    products.forEach((p) => {
      if (!list.includes(p.category)) {
        list.push(p.category);
      }
    });
    return list;
  }, [categories, products]);

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesCat =
        selectedCategory === 'All' || p.category === selectedCategory;

      if (!matchesCat) return false;

      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        (p.nameHindi && p.nameHindi.toLowerCase().includes(q)) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    });
  }, [products, selectedCategory, searchQuery]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-emerald-200">
      {viewMode === 'owner' ? (
        /* OWNER SIDE: Owner Dashboard with Shop QR Code Section inside Settings */
        <OwnerDashboard
          shop={shop}
          categories={categories}
          products={products}
          orders={orders}
          onUpdateShop={(updated) => setShop((prev) => ({ ...prev, ...updated }))}
          onUpdateCategories={setCategories}
          onUpdateProducts={setProducts}
          onUpdateOrders={setOrders}
          onSwitchToCustomer={() => setViewMode('customer')}
          initialTab={ownerInitialTab}
        />
      ) : (
        /* CUSTOMER SIDE: Single-Shop Home with Scan Shop QR, Product Catalog, Cart */
        <div className="flex flex-col min-h-screen">
          {/* Header */}
          <CustomerHeader
            shop={shop}
            cartCount={totalCartCount}
            cartTotal={cartTotalAmount}
            onOpenCart={() => setIsCartOpen(true)}
            onOpenScanner={() => setIsScannerOpen(true)}
            onOpenOrders={() => setIsOrdersOpen(true)}
            onSwitchToOwner={() => {
              setOwnerInitialTab('qr_code');
              setViewMode('owner');
            }}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />

          {/* Main Body */}
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-4 sm:py-6">
            {/* Shop Identification Banner (When arrived via QR scan or URL parameter) */}
            {showIdentifiedBanner && (
              <ShopIdentificationBanner
                shop={shop}
                onDismiss={() => setShowIdentifiedBanner(false)}
                onReScan={() => setIsScannerOpen(true)}
              />
            )}

            {/* Customer Home Screen Hero / Quick Actions */}
            <div className="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-6 mb-6 shadow-2xs">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                      Local Neighbourhood Store
                    </span>
                    <span className="text-xs text-slate-500">• Single-Shop Direct</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                    Order Fresh Groceries Directly from {shop.name}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600">
                    Direct local pricing • 30-min express delivery • No middleman markups
                  </p>
                </div>

                {/* Prominent "Scan Shop QR" and "Share Shop QR" Quick Buttons on Customer Home Screen */}
                <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
                  <button
                    id="home-hero-scan-qr-btn"
                    onClick={() => setIsScannerOpen(true)}
                    className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2.5 rounded-xl shadow-xs transition-all active:scale-[0.98] cursor-pointer text-xs sm:text-sm"
                    title="Scan store counter QR code with camera"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>Scan Shop QR</span>
                  </button>

                  <button
                    id="home-hero-share-qr-btn"
                    onClick={() => {
                      shareShopQRCode(shop, getShopUrl(shop)).then((res) => {
                        alert(res.message);
                      });
                    }}
                    className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium px-3.5 py-2.5 rounded-xl transition-all cursor-pointer text-xs sm:text-sm"
                    title="Share this shop link or QR code with friends & family"
                  >
                    <Share2 className="w-3.5 h-3.5 text-slate-600" />
                    <span>Share Shop QR</span>
                  </button>
                </div>
              </div>

              {/* Service Highlights */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-100 text-xs">
                <div className="flex items-center gap-2 text-slate-700">
                  <Truck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Free delivery over {shop.currency}{shop.freeDeliveryAbove}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Delivered in 30 mins</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>100% Pure & Fresh Quality</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="truncate">{shop.address.split(',')[0]}</span>
                </div>
              </div>
            </div>

            {/* Category Filter Chips */}
            <div className="mb-6 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 pl-1 shrink-0">
                <Filter className="w-3.5 h-3.5" />
                <span>Filter:</span>
              </span>
              {categoryNames.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-emerald-700 text-white font-semibold shadow-2xs'
                      : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Products Grid */}
            <div className="mb-10">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    {selectedCategory === 'All' ? 'All Products' : selectedCategory}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Showing {filteredProducts.length} items from {shop.name}
                  </p>
                </div>
              </div>

              {filteredProducts.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-400">
                  <Search className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                  <p className="font-semibold text-slate-700 text-sm">
                    No products found
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Try searching for another term or clear the filter.
                  </p>
                  <button
                    onClick={() => {
                      setSelectedCategory('All');
                      setSearchQuery('');
                    }}
                    className="mt-3 text-xs text-emerald-700 underline font-semibold cursor-pointer"
                  >
                    View All Products
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
                  {filteredProducts.map((prod) => {
                    const cartItem = cart.find((item) => item.product.id === prod.id);
                    return (
                      <ProductCard
                        key={prod.id}
                        product={prod}
                        quantityInCart={cartItem ? cartItem.quantity : 0}
                        onAddToCart={handleAddToCart}
                        onUpdateQuantity={handleUpdateQuantity}
                        currency={shop.currency}
                      />
                    );
                  })}
                </div>
              )}
            </div>

            {/* Floating Mobile Cart Bar */}
            {totalCartCount > 0 && !isCartOpen && (
              <div className="fixed bottom-4 left-4 right-4 z-30 max-w-md mx-auto md:hidden">
                <button
                  id="mobile-floating-cart-btn"
                  onClick={() => setIsCartOpen(true)}
                  className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-3 px-4 rounded-2xl shadow-xl flex items-center justify-between transition-all active:scale-[0.99] cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center font-bold text-xs">
                      {totalCartCount}
                    </div>
                    <div className="text-left leading-tight">
                      <p className="text-xs font-bold">{shop.currency}{cartTotalAmount}</p>
                      <p className="text-[10px] text-emerald-200">View Cart & Checkout</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-xs font-bold">
                    <span>Checkout</span>
                    <ShoppingBag className="w-4 h-4 ml-1" />
                  </div>
                </button>
              </div>
            )}
          </main>

          {/* Footer with Shop Information and QR code prompt */}
          <footer className="bg-white border-t border-slate-200 mt-auto py-8 px-4 text-xs text-slate-500">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3 text-center md:text-left">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-base">
                  {shop.name.charAt(0)}
                </div>
                <div>
                  <p className="font-bold text-slate-800">{shop.name}</p>
                  <p className="text-[11px] text-slate-400">
                    {shop.address} • Contact: {shop.phone}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsScannerOpen(true)}
                  className="flex items-center gap-1.5 text-emerald-700 hover:text-emerald-900 font-semibold cursor-pointer"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Scan Shop QR</span>
                </button>
                <span>•</span>
                <button
                  onClick={() => {
                    setOwnerInitialTab('qr_code');
                    setViewMode('owner');
                  }}
                  className="text-slate-600 hover:text-slate-900 font-medium cursor-pointer"
                >
                  Owner Settings
                </button>
              </div>
            </div>
          </footer>

          {/* Customer Modals */}
          <CustomerScannerModal
            isOpen={isScannerOpen}
            onClose={() => setIsScannerOpen(false)}
            currentShop={shop}
            onShopIdentified={handleShopIdentifiedFromQR}
          />

          <CartDrawer
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            cartItems={cart}
            shop={shop}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveFromCart}
            onCheckout={() => {
              setIsCartOpen(false);
              setIsCheckoutOpen(true);
            }}
          />

          <CheckoutModal
            isOpen={isCheckoutOpen}
            onClose={() => setIsCheckoutOpen(false)}
            cartItems={cart}
            shop={shop}
            onPlaceOrder={handlePlaceOrder}
            onClearCart={handleClearCart}
          />

          <CustomerOrdersModal
            isOpen={isOrdersOpen}
            onClose={() => setIsOrdersOpen(false)}
            orders={orders}
            shop={shop}
          />
        </div>
      )}
    </div>
  );
}
