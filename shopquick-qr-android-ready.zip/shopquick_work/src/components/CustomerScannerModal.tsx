import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { X, Camera, Upload, Sparkles, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { ShopInfo } from '../types';
import { getShopUrl } from '../utils/qrHelper';

interface CustomerScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentShop: ShopInfo;
  onShopIdentified: (shopId: string, shopName: string) => void;
}

export const CustomerScannerModal: React.FC<CustomerScannerModalProps> = ({
  isOpen,
  onClose,
  currentShop,
  onShopIdentified,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [scanSuccess, setScanSuccess] = useState<string | null>(null);

  // Start / stop camera stream
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setScanSuccess(null);
      setCameraError(null);
      return;
    }

    startCamera();

    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    setHasCameraPermission(null);

    // Check if mediaDevices is supported
    if (!navigator?.mediaDevices?.getUserMedia) {
      setHasCameraPermission(false);
      setCameraError('Camera access is not supported in this browser or iframe environment.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        setHasCameraPermission(true);
        startScanningLoop();
      }
    } catch (err: any) {
      console.warn('Camera access denied or unavailable:', err);
      setHasCameraPermission(false);
      setCameraError(
        err.name === 'NotAllowedError'
          ? 'Camera permission was denied. You can still upload a QR image or click the instant test scan button below.'
          : 'Unable to connect to camera on this device. You can test with file upload or instant scan below.'
      );
    }
  };

  const stopCamera = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const startScanningLoop = () => {
    const scan = () => {
      if (!videoRef.current || !canvasRef.current) return;

      const video = videoRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      if (video.readyState === video.HAVE_ENOUGH_DATA && ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          handleQRCodeDetected(code.data);
          return;
        }
      }

      animationFrameRef.current = requestAnimationFrame(scan);
    };

    animationFrameRef.current = requestAnimationFrame(scan);
  };

  const handleQRCodeDetected = (data: string) => {
    stopCamera();
    setIsProcessing(true);

    try {
      // Parse QR code data
      let targetShopId = '';
      if (data.includes('shop=')) {
        try {
          const url = new URL(data, window.location.origin);
          targetShopId = url.searchParams.get('shop') || '';
        } catch {
          const match = data.match(/shop=([^&]+)/);
          if (match) targetShopId = decodeURIComponent(match[1]);
        }
      } else if (data.startsWith('shop-') || data.startsWith('shop_')) {
        targetShopId = data.trim();
      } else {
        // Assume raw payload or link
        targetShopId = currentShop.id;
      }

      // In single-shop mode, identify the store
      const identifiedShopName = currentShop.name;
      setScanSuccess(identifiedShopName);

      setTimeout(() => {
        setIsProcessing(false);
        onShopIdentified(targetShopId || currentShop.id, identifiedShopName);
        onClose();
      }, 900);
    } catch (e) {
      console.error('Error processing scanned QR code:', e);
      setIsProcessing(false);
      startCamera();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);

        if (code && code.data) {
          handleQRCodeDetected(code.data);
        } else {
          alert('No readable QR code found in the selected image. Please try another image or use Instant Test Scan.');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleInstantTestScan = () => {
    // Generates the shop's exact QR content and simulates a direct scan
    const shopUrl = getShopUrl(currentShop);
    handleQRCodeDetected(shopUrl);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-800">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 text-sm">Scan Shop QR Code</h3>
              <p className="text-[11px] text-slate-500">दुकान का QR कोड स्कैन करें</p>
            </div>
          </div>
          <button
            id="close-scanner-modal-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scanner Viewport */}
        <div className="relative bg-slate-950 flex flex-col items-center justify-center min-h-[280px] sm:min-h-[320px] overflow-hidden">
          {scanSuccess ? (
            <div className="flex flex-col items-center justify-center p-6 text-center text-white animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3 ring-8 ring-emerald-500/10">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-lg font-bold text-white">Shop Identified!</h4>
              <p className="text-emerald-300 font-semibold text-base mt-1">{scanSuccess}</p>
              <p className="text-xs text-slate-400 mt-2">Opening Home Page to browse products...</p>
            </div>
          ) : hasCameraPermission === false || cameraError ? (
            <div className="p-6 text-center max-w-xs flex flex-col items-center">
              <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h4 className="text-white text-sm font-semibold mb-1">Camera Stream Inactive</h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                {cameraError || 'Use the instant scan button below to simulate scanning our store QR code directly.'}
              </p>
              <button
                onClick={startCamera}
                className="inline-flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 underline font-medium cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Retry Camera Access
              </button>
            </div>
          ) : (
            <>
              {/* Video stream */}
              <video
                ref={videoRef}
                className="w-full h-full object-cover min-h-[280px]"
                autoPlay
                playsInline
                muted
              />
              <canvas ref={canvasRef} className="hidden" />

              {/* Scanning Crosshair Overlay */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="relative w-56 h-56 rounded-2xl border-2 border-emerald-400/90 shadow-[0_0_0_9999px_rgba(15,23,42,0.65)]">
                  {/* Corner markers */}
                  <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-emerald-400 rounded-tl-lg" />
                  <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-emerald-400 rounded-tr-lg" />
                  <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-emerald-400 rounded-bl-lg" />
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-emerald-400 rounded-br-lg" />

                  {/* Animated scanning laser line */}
                  <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent absolute top-0 animate-[bounce_2s_infinite] shadow-[0_0_8px_#34d399]" />
                </div>
              </div>

              {/* Instruction banner over scanner */}
              <div className="absolute bottom-3 left-4 right-4 bg-slate-900/80 backdrop-blur-xs text-white px-3 py-1.5 rounded-lg text-center text-xs border border-white/10">
                Point camera at the <span className="font-semibold text-emerald-400">{currentShop.name}</span> QR code
              </div>
            </>
          )}
        </div>

        {/* Scan Actions & Instant Test Button */}
        <div className="p-4 bg-white border-t border-slate-100 flex flex-col gap-2.5">
          {/* Instant Test Scan button */}
          <button
            id="instant-test-scan-shop-qr-btn"
            onClick={handleInstantTestScan}
            disabled={isProcessing}
            className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2.5 px-4 rounded-xl transition-all shadow-xs active:scale-[0.99] cursor-pointer text-xs sm:text-sm"
          >
            <Sparkles className="w-4 h-4 text-emerald-200" />
            <span>Instant Test Scan ({currentShop.name} QR)</span>
          </button>

          <div className="flex items-center gap-2 text-slate-400 text-xs my-0.5">
            <div className="h-px bg-slate-200 flex-1" />
            <span>or scan from file</span>
            <div className="h-px bg-slate-200 flex-1" />
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-medium transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-slate-500" />
              <span>Upload QR Image</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>

          <p className="text-[11px] text-slate-500 text-center leading-tight">
            Scanning automatically connects your phone to <span className="font-medium text-slate-700">{currentShop.name}</span> and opens the live catalog.
          </p>
        </div>
      </div>
    </div>
  );
};
