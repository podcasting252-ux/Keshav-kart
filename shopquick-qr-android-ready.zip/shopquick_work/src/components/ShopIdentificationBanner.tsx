import React from 'react';
import { CheckCircle, QrCode, X } from 'lucide-react';
import { ShopInfo } from '../types';

interface ShopIdentificationBannerProps {
  shop: ShopInfo;
  onDismiss: () => void;
  onReScan: () => void;
}

export const ShopIdentificationBanner: React.FC<ShopIdentificationBannerProps> = ({
  shop,
  onDismiss,
  onReScan,
}) => {
  return (
    <div className="bg-gradient-to-r from-emerald-600 via-emerald-700 to-teal-700 text-white rounded-2xl p-4 shadow-sm mb-6 border border-emerald-500/30">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 text-white border border-white/20 mt-0.5 sm:mt-0">
            <CheckCircle className="w-5 h-5 text-emerald-200" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[11px] font-bold tracking-wider uppercase bg-emerald-900/60 px-2 py-0.5 rounded text-emerald-200 border border-emerald-400/30">
                Verified Shop Connected
              </span>
              <span className="text-xs text-emerald-100 font-medium">via Shop QR</span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white mt-0.5">
              Welcome to {shop.name}
            </h2>
            <p className="text-xs text-emerald-100/90 mt-0.5">
              हमारी दुकान में आपका स्वागत है! You are shopping directly with our local store.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          <button
            onClick={onReScan}
            className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-all border border-white/20 cursor-pointer"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Scan Another QR</span>
          </button>
          <button
            onClick={onDismiss}
            className="w-7 h-7 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer"
            title="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
