import React from 'react';
import { QrCode, ShoppingBag, Store, Search, ClipboardList, Download } from 'lucide-react';
import { ShopInfo } from '../types';

interface CustomerHeaderProps {
  shop: ShopInfo;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  onOpenScanner: () => void;
  onOpenOrders: () => void;
  onSwitchToOwner: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export const CustomerHeader: React.FC<CustomerHeaderProps> = ({
  shop,
  cartCount,
  cartTotal,
  onOpenCart,
  onOpenScanner,
  onOpenOrders,
  onSwitchToOwner,
  searchQuery,
  onSearchChange,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-emerald-100 shadow-xs">
      {/* Top Banner with Shop details & Owner Switcher */}
      <div className="bg-emerald-800 text-white text-xs px-4 py-1.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 truncate">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-medium truncate">
              {shop.name} • {shop.openingHours}
            </span>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <a
              id="customer-download-zip-link"
              href="/project.zip"
              download="apna-mart-project.zip"
              className="flex items-center gap-1 text-emerald-100 hover:text-white transition-colors cursor-pointer px-2 py-0.5 rounded-sm hover:bg-emerald-700/50"
              title="Download full project source code as ZIP"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Project ZIP</span>
            </a>
            <span className="text-emerald-500">|</span>
            <button
              id="customer-my-orders-btn"
              onClick={onOpenOrders}
              className="flex items-center gap-1 text-emerald-100 hover:text-white transition-colors cursor-pointer px-2 py-0.5 rounded-sm hover:bg-emerald-700/50"
            >
              <ClipboardList className="w-3.5 h-3.5" />
              <span>My Orders</span>
            </button>
            <span className="text-emerald-500">|</span>
            <button
              id="switch-to-owner-btn"
              onClick={onSwitchToOwner}
              className="flex items-center gap-1.5 bg-emerald-900/80 hover:bg-emerald-950 text-emerald-200 hover:text-white font-medium px-2.5 py-0.5 rounded-md transition-all border border-emerald-600/40 cursor-pointer text-xs"
              title="Switch to Store Owner management panel"
            >
              <Store className="w-3.5 h-3.5 text-emerald-300" />
              <span>Owner Mode</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-3 sm:gap-6">
          {/* Shop Name & Logo */}
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-bold text-xl shadow-xs shrink-0">
              {shop.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-slate-900 text-base sm:text-lg leading-tight truncate">
                  {shop.name}
                </h1>
                <span className="hidden sm:inline-flex items-center text-[10px] uppercase font-semibold tracking-wide bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
                  Direct Store
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate hidden sm:block">
                {shop.tagline}
              </p>
            </div>
          </div>

          {/* Search bar (desktop) */}
          <div className="hidden md:flex flex-1 max-w-md relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="product-search-input"
              type="text"
              placeholder="Search atta, dal, milk, veggies, snacks..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500 focus:bg-white transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>

          {/* Actions: Scan Shop QR + Cart */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Scan Shop QR button prominently on customer home screen */}
            <button
              id="customer-scan-shop-qr-btn"
              onClick={onOpenScanner}
              className="flex items-center gap-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold px-3 sm:px-3.5 py-2 rounded-xl transition-all shadow-2xs active:scale-95 cursor-pointer text-xs sm:text-sm"
              title="Scan Shop QR to connect directly"
            >
              <QrCode className="w-4 h-4 text-emerald-700 shrink-0" />
              <span className="font-medium">Scan Shop QR</span>
            </button>

            {/* Cart Button */}
            <button
              id="customer-cart-btn"
              onClick={onOpenCart}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium px-3.5 py-2 rounded-xl transition-all shadow-xs active:scale-95 cursor-pointer text-xs sm:text-sm"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-400 text-slate-900 text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-white">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline">Cart</span>
              {cartCount > 0 && (
                <span className="bg-emerald-700/60 px-1.5 py-0.5 rounded text-xs font-semibold">
                  {shop.currency}{cartTotal}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Search bar (mobile) */}
        <div className="mt-2.5 md:hidden relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="product-search-input-mobile"
            type="text"
            placeholder="Search groceries, milk, vegetables..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500 focus:bg-white"
          />
        </div>
      </div>
    </header>
  );
};
