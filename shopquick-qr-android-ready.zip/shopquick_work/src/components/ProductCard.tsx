import React from 'react';
import { Plus, Minus } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  quantityInCart: number;
  onAddToCart: (p: Product) => void;
  onUpdateQuantity: (productId: string, delta: number) => void;
  currency: string;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  quantityInCart,
  onAddToCart,
  onUpdateQuantity,
  currency,
}) => {
  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 hover:border-emerald-300 shadow-2xs hover:shadow-sm transition-all duration-200 flex flex-col overflow-hidden group">
      {/* Product Image & Badges */}
      <div className="relative h-44 bg-slate-100 overflow-hidden shrink-0">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {/* Veg icon */}
        {product.isVeg && (
          <div className="absolute top-2.5 left-2.5 bg-white/90 backdrop-blur-xs p-1 rounded-md border border-slate-200/80 shadow-2xs">
            <div className="w-3.5 h-3.5 border border-emerald-600 flex items-center justify-center rounded-xs">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
            </div>
          </div>
        )}

        {/* Promotional / Special Badge */}
        {product.badge && (
          <span className="absolute top-2.5 right-2.5 bg-emerald-700 text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-2xs">
            {product.badge}
          </span>
        )}

        {/* Discount Badge */}
        {discountPercent > 0 && (
          <span className="absolute bottom-2 left-2.5 bg-amber-500 text-slate-950 text-[10px] font-bold px-1.5 py-0.5 rounded shadow-2xs">
            {discountPercent}% OFF
          </span>
        )}

        {/* Out of Stock Overlay */}
        {!product.inStock && (
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center">
            <span className="bg-rose-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              Out of Stock
            </span>
          </div>
        )}
      </div>

      {/* Product Details */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between">
        <div>
          <span className="text-[11px] font-medium text-slate-400 block mb-0.5">
            {product.unit}
          </span>
          <h3 className="font-semibold text-slate-900 text-sm sm:text-base leading-snug line-clamp-2">
            {product.name}
          </h3>
          {product.nameHindi && (
            <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
              {product.nameHindi}
            </p>
          )}
        </div>

        {/* Price & Add to Cart Controls */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="font-bold text-slate-900 text-base sm:text-lg">
                {currency}{product.retailPrice ?? product.price}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-slate-400 line-through">
                  {currency}{product.originalPrice}
                </span>
              )}
            </div>
            {product.wholesalePrice ? (
              <p className="text-[10px] text-emerald-800 font-medium leading-none mt-0.5">
                Bulk: {currency}{product.wholesalePrice}
              </p>
            ) : null}
            {product.stock !== undefined && product.stock > 0 && product.stock <= 5 && (
              <p className="text-[10px] text-amber-700 font-semibold leading-none mt-0.5">
                Only {product.stock} left
              </p>
            )}
          </div>

          {/* Add / Quantity Button */}
          {product.inStock ? (
            quantityInCart > 0 ? (
              <div className="flex items-center bg-emerald-50 border border-emerald-300 rounded-xl overflow-hidden shadow-2xs">
                <button
                  id={`product-decrease-${product.id}`}
                  onClick={() => onUpdateQuantity(product.id, -1)}
                  className="w-7 h-7 flex items-center justify-center text-emerald-800 hover:bg-emerald-100 transition-colors cursor-pointer"
                  title="Decrease quantity"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-7 text-center font-bold text-xs text-emerald-950">
                  {quantityInCart}
                </span>
                <button
                  id={`product-increase-${product.id}`}
                  onClick={() => onUpdateQuantity(product.id, 1)}
                  className="w-7 h-7 flex items-center justify-center text-emerald-800 hover:bg-emerald-100 transition-colors cursor-pointer"
                  title="Increase quantity"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                id={`product-add-${product.id}`}
                onClick={() => onAddToCart(product)}
                className="flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold px-3 py-1.5 rounded-xl text-xs sm:text-sm transition-all shadow-2xs active:scale-95 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            )
          ) : (
            <span className="text-xs text-slate-400 italic">Unavailable</span>
          )}
        </div>
      </div>
    </div>
  );
};
