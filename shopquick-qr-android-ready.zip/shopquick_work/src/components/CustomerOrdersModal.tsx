import React from 'react';
import { X, PackageCheck, Clock, CheckCircle2, ChevronRight, ShoppingBag } from 'lucide-react';
import { Order, ShopInfo } from '../types';

interface CustomerOrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  shop: ShopInfo;
}

export const CustomerOrdersModal: React.FC<CustomerOrdersModalProps> = ({
  isOpen,
  onClose,
  orders,
  shop,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-100 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <PackageCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">My Orders</h3>
              <p className="text-xs text-slate-500">Track current and past deliveries</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {orders.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <ShoppingBag className="w-12 h-12 mx-auto mb-2 text-slate-300" />
              <p className="font-semibold text-slate-700 text-sm">No orders yet</p>
              <p className="text-xs text-slate-500 mt-0.5">Your orders placed with {shop.name} will appear here.</p>
            </div>
          ) : (
            orders.map((order) => {
              const statusColor =
                order.status === 'delivered'
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  : order.status === 'out_for_delivery'
                  ? 'bg-blue-100 text-blue-800 border-blue-300'
                  : order.status === 'accepted'
                  ? 'bg-amber-100 text-amber-800 border-amber-300'
                  : 'bg-slate-100 text-slate-700 border-slate-200';

              const statusText =
                order.status === 'delivered'
                  ? 'Delivered'
                  : order.status === 'out_for_delivery'
                  ? 'Out for Delivery'
                  : order.status === 'accepted'
                  ? 'Order Accepted'
                  : 'Order Placed';

              return (
                <div
                  key={order.id}
                  className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-2xs hover:border-emerald-300 transition-colors"
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-xs">
                    <div>
                      <span className="font-bold text-slate-900">{order.id}</span>
                      <span className="text-slate-400 ml-2">
                        {new Date(order.createdAt).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${statusColor}`}>
                      {statusText}
                    </span>
                  </div>

                  {/* Items summary */}
                  <div className="py-2 text-xs space-y-1">
                    {(order.orderItems && order.orderItems.length > 0
                      ? order.orderItems.map((item) => ({
                          name: item.name,
                          quantity: item.quantity,
                          price: item.price,
                          unit: item.unit,
                        }))
                      : order.items.map((item) => ({
                          name: item.product.name,
                          quantity: item.quantity,
                          price: item.product.retailPrice ?? item.product.price,
                          unit: item.product.unit,
                        }))
                    ).map((item, idx) => (
                      <div key={idx} className="flex justify-between text-slate-600">
                        <span className="truncate pr-2">
                          {item.name} {item.unit ? `(${item.unit})` : ''} × {item.quantity}
                        </span>
                        <span className="font-medium shrink-0">
                          {shop.currency}{item.price * item.quantity}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500">
                      {order.pickupOrDelivery === 'pickup' || order.customer.deliveryType === 'pickup'
                        ? 'Store Pickup'
                        : 'Home Delivery'} • <span className="font-medium text-slate-800 uppercase">{order.customer.paymentMethod}</span>
                    </span>
                    <span className="font-bold text-slate-900 text-sm">
                      Total: {shop.currency}{order.totalAmount || order.grandTotal}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
