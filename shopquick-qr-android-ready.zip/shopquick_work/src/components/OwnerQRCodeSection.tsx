import React, { useEffect, useState } from 'react';
import {
  Download,
  Share2,
  Printer,
  Copy,
  Check,
  RefreshCw,
  ExternalLink,
  Store,
  ShieldCheck,
  CheckCircle,
  FileImage,
} from 'lucide-react';
import { ShopInfo } from '../types';
import {
  getShopUrl,
  generateQRCodeDataUrl,
  downloadStyledShopQRCode,
  downloadRawQRCode,
  shareShopQRCode,
} from '../utils/qrHelper';

interface OwnerQRCodeSectionProps {
  shop: ShopInfo;
  onUpdateShop: (updated: Partial<ShopInfo>) => void;
}

export const OwnerQRCodeSection: React.FC<OwnerQRCodeSectionProps> = ({
  shop,
  onUpdateShop,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [isLoadingQr, setIsLoadingQr] = useState<boolean>(true);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [shareToast, setShareToast] = useState<string | null>(null);
  const [showRegenModal, setShowRegenModal] = useState<boolean>(false);
  const [showPrintPreview, setShowPrintPreview] = useState<boolean>(false);

  const shopUrl = getShopUrl(shop);

  // Generate QR code dynamically when shop.id or shop.qrVersion changes
  useEffect(() => {
    let isMounted = true;
    setIsLoadingQr(true);

    generateQRCodeDataUrl(shopUrl)
      .then((dataUrl) => {
        if (isMounted) {
          setQrDataUrl(dataUrl);
          setIsLoadingQr(false);
        }
      })
      .catch((err) => {
        console.error('Failed to generate QR code in OwnerQRCodeSection:', err);
        if (isMounted) setIsLoadingQr(false);
      });

    return () => {
      isMounted = false;
    };
  }, [shopUrl]);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shopUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      alert('Could not copy link automatically. Please select and copy the text box.');
    }
  };

  const handleShareQRCode = async () => {
    const result = await shareShopQRCode(shop, shopUrl);
    setShareToast(result.message);
    setTimeout(() => setShareToast(null), 3500);
  };

  const handleDownloadStyled = async () => {
    if (!qrDataUrl) return;
    await downloadStyledShopQRCode(shop, qrDataUrl);
  };

  const handleDownloadRaw = () => {
    if (!qrDataUrl) return;
    downloadRawQRCode(qrDataUrl, shop.name);
  };

  const handlePrintQRCode = () => {
    window.print();
  };

  const handleConfirmRegenerate = () => {
    // Generate new unique ID & increment QR version
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const slug = shop.name.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 16);
    const newId = `shop-${slug}-${randomSuffix}`;
    onUpdateShop({
      id: newId,
      qrVersion: (shop.qrVersion || 1) + 1,
    });
    setShowRegenModal(false);
    setShareToast('Shop QR code and identifier regenerated successfully!');
    setTimeout(() => setShareToast(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Toast message if any */}
      {shareToast && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-sm flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{shareToast}</span>
        </div>
      )}

      {/* Main Shop QR Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {/* Header bar */}
        <div className="bg-gradient-to-r from-emerald-800 to-emerald-900 text-white p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[11px] font-bold tracking-wider uppercase bg-emerald-700/80 px-2 py-0.5 rounded text-emerald-200">
                  Store Identity
                </span>
                <span className="text-xs text-emerald-300 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Unique Shop Link
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
                {shop.name}
              </h2>
              <p className="text-xs sm:text-sm text-emerald-200/90 mt-0.5">
                Share this official QR code with your customers to take orders directly.
              </p>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-center">
              <button
                id="owner-test-open-shop-url-btn"
                onClick={() => window.open(shopUrl, '_blank')}
                className="flex items-center gap-1.5 bg-emerald-700/60 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-2 rounded-xl border border-emerald-500/40 transition-colors cursor-pointer"
                title="Test how customer sees this shop via the link"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Test Shop Link</span>
              </button>
            </div>
          </div>
        </div>

        {/* QR Display and Actions Area */}
        <div className="p-6 sm:p-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: Large Crisp QR Code with required instructions */}
            <div className="lg:col-span-6 flex flex-col items-center">
              {/* The printable and display container */}
              <div
                id="print-shop-qr"
                className="w-full max-w-sm bg-white rounded-2xl p-6 border-2 border-slate-200 shadow-sm flex flex-col items-center text-center transition-all hover:border-emerald-300"
              >
                {/* Standee Store Tag */}
                <div className="flex items-center gap-1.5 text-emerald-800 font-bold text-sm bg-emerald-50 px-3 py-1 rounded-full mb-3 border border-emerald-200">
                  <Store className="w-4 h-4 text-emerald-600" />
                  <span>{shop.name}</span>
                </div>

                {/* QR Code Container (Large and easy to scan) */}
                <div className="relative w-64 h-64 sm:w-72 sm:h-72 bg-white rounded-xl p-3 border border-slate-100 shadow-inner flex items-center justify-center">
                  {isLoadingQr ? (
                    <div className="flex flex-col items-center gap-2 text-slate-400">
                      <RefreshCw className="w-8 h-8 animate-spin text-emerald-600" />
                      <span className="text-xs">Generating unique QR...</span>
                    </div>
                  ) : qrDataUrl ? (
                    <img
                      src={qrDataUrl}
                      alt={`Shop QR Code for ${shop.name}`}
                      className="w-full h-full object-contain rounded-lg"
                      id="shop-qr-image-element"
                    />
                  ) : (
                    <span className="text-xs text-rose-500">Failed to render QR</span>
                  )}
                </div>

                {/* Short instructions below QR (Prompt verbatim requirements) */}
                <div className="mt-4 pt-4 border-t border-slate-100 w-full">
                  <p className="font-bold text-slate-900 text-sm sm:text-base leading-tight">
                    Scan this QR code to open our shop
                  </p>
                  <p className="font-bold text-emerald-700 text-sm sm:text-base leading-tight mt-1">
                    हमारी दुकान खोलने के लिए QR कोड स्कैन करें
                  </p>
                  <p className="text-[11px] text-slate-500 mt-2 font-medium">
                    Instant delivery • Fresh products • Direct shop prices
                  </p>
                </div>
              </div>

              <span className="text-xs text-slate-400 mt-2">
                Unique Shop ID: <span className="font-mono text-slate-600">{shop.id}</span>
              </span>
            </div>

            {/* Right: Actions, Share Shop QR, Download & Print */}
            <div className="lg:col-span-6 flex flex-col justify-center space-y-5">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <span>Share Shop QR</span>
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  Display this QR code at your shop counter, billing desk, or share it on WhatsApp so regular customers can open your store with a single phone scan.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Download QR Code button */}
                <button
                  id="owner-download-qr-btn"
                  onClick={handleDownloadStyled}
                  disabled={isLoadingQr || !qrDataUrl}
                  className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-4 rounded-xl shadow-xs active:scale-[0.98] transition-all cursor-pointer text-xs sm:text-sm"
                  title="Download printable counter standee image"
                >
                  <Download className="w-4 h-4" />
                  <span>Download QR Code</span>
                </button>

                {/* Share QR Code button */}
                <button
                  id="owner-share-qr-btn"
                  onClick={handleShareQRCode}
                  className="flex items-center justify-center gap-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold py-3 px-4 rounded-xl shadow-2xs active:scale-[0.98] transition-all cursor-pointer text-xs sm:text-sm"
                  title="Share Shop QR link to WhatsApp or social apps"
                >
                  <Share2 className="w-4 h-4 text-emerald-700" />
                  <span>Share QR Code</span>
                </button>

                {/* Print QR Code option */}
                <button
                  id="owner-print-qr-btn"
                  onClick={handlePrintQRCode}
                  className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 font-semibold py-2.5 px-4 rounded-xl transition-all cursor-pointer text-xs sm:text-sm"
                  title="Print this QR standee on paper or sticker"
                >
                  <Printer className="w-4 h-4 text-slate-600" />
                  <span>Print QR Code</span>
                </button>

                {/* Download raw QR image only */}
                <button
                  id="owner-download-raw-qr-btn"
                  onClick={handleDownloadRaw}
                  className="flex items-center justify-center gap-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 font-medium py-2.5 px-4 rounded-xl transition-all cursor-pointer text-xs sm:text-sm"
                  title="Download transparent high-res QR PNG for printing stickers"
                >
                  <FileImage className="w-4 h-4 text-slate-500" />
                  <span>Download QR Image Only</span>
                </button>
              </div>

              {/* Unique Shop Link Container */}
              <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Permanent Shop URL:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={shopUrl}
                    className="w-full text-xs font-mono bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-700 select-all focus:outline-none"
                  />
                  <button
                    id="owner-copy-shop-url-btn"
                    onClick={handleCopyLink}
                    className="flex items-center gap-1 bg-white hover:bg-slate-100 border border-slate-200 px-3 py-2 rounded-lg text-xs font-medium text-slate-700 shrink-0 cursor-pointer shadow-2xs"
                  >
                    {copiedLink ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-semibold">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-500" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  This exact link is encoded inside the QR code. When customers scan it, your shop opens automatically.
                </p>
              </div>

              {/* Regenerate Option info */}
              <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100">
                <div className="text-slate-500">
                  <span>QR is static and permanent for this shop.</span>
                </div>
                <button
                  id="owner-regenerate-qr-btn"
                  onClick={() => setShowRegenModal(true)}
                  className="text-slate-500 hover:text-amber-700 underline flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Regenerate Shop QR</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation modal for Regenerate */}
      {showRegenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 border border-slate-200 shadow-xl">
            <h4 className="font-bold text-slate-900 text-base mb-1.5">Regenerate Shop QR Code?</h4>
            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Your existing printed QR codes and shared links will be updated with a new identifier. Only regenerate if you want to invalidate previous QR codes.
            </p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowRegenModal(false)}
                className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmRegenerate}
                className="px-3.5 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white rounded-lg cursor-pointer shadow-xs"
              >
                Yes, Regenerate QR
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
