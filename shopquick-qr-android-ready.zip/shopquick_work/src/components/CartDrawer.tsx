import React from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, ShieldCheck } from 'lucide-react';
import { CartItem, ShopInfo } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  shop: ShopInfo;
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  shop,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}) => {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const isFreeDelivery = subtotal >= shop.freeDeliveryAbove;
  const deliveryFee = subtotal === 0 ? 0 : isFreeDelivery ? 0 : shop.deliveryFee;
  const totalPayable = subtotal + deliveryFee;
  const progressToFreeDelivery = Math.min(100, Math.round((subtotal / shop.freeDeliveryAbove) * 100));
  const amountNeededForFreeDelivery = Math.max(0, shop.freeDeliveryAbove - subtotal);

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-2xs">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-800">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Your Cart</h3>
              <p className="text-xs text-slate-500">
                {cartItems.reduce((acc, i) => acc + i.quantity, 0)} items from {shop.name}
              </p>
            </div>
          </div>
          <button
            id="close-cart-drawer-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Free Delivery Bar */}
        {cartItems.length > 0 && (
          <div className="bg-emerald-50 px-4 py-2.5 border-b border-emerald-100 text-xs">
            {isFreeDelivery ? (
              <p className="text-emerald-800 font-semibold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>You unlocked FREE Delivery on this order!</span>
              </p>
            ) : (
              <div>
                <p className="text-emerald-900 font-medium">
                  Add <span className="font-bold text-emerald-800">{shop.currency}{amountNeededForFreeDelivery}</span> more for FREE delivery
                </p>
                <div className="w-full bg-emerald-200 h-1.5 rounded-full mt-1.5 overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${progressToFreeDelivery}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cartItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-3 text-slate-300">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h4 className="font-semibold text-slate-700 text-base">Your cart is empty</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                Browse our fresh products and add your favorite items to begin.
              </p>
            </div>
          ) : (
            cartItems.map((item) => (
              <div
                key={item.product.id}
                className="flex items-center gap-3 p-2.5 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors"
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-16 h-16 rounded-lg object-cover bg-white shrink-0 border border-slate-200/60"
                />

                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-slate-900 text-xs sm:text-sm truncate">
                    {item.product.name}
                  </h4>
                  <p className="text-[11px] text-slate-500">{item.product.unit}</p>
                  <p className="font-bold text-slate-900 text-xs sm:text-sm mt-0.5">
                    {shop.currency}{item.product.price}
                  </p>
                </div>

                {/* Quantity adjuster */}
                <div className="flex items-center bg-white border border-slate-200 rounded-lg overflow-hidden shrink-0 shadow-2xs">
                  <button
                    onClick={() => onUpdateQuantity(item.product.id, -1)}
                    className="w-6 h-6 flex items-center justify-center text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-6 text-center font-bold text-xs text-slate-800">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => onUpdateQuantity(item.product.id, 1)}
                    className="w-6 h-6 flex items-center justify-center text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>

                <button
                  onClick={() => onRemoveItem(item.product.id)}
                  className="text-slate-300 hover:text-rose-500 p-1.5 transition-colors cursor-pointer"
                  title="Remove item"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Bill Summary & Checkout Button */}
        {cartItems.length > 0 && (
          <div className="p-4 bg-white border-t border-slate-100 shadow-lg space-y-3">
            <div className="space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Items Subtotal</span>
                <span className="font-semibold text-slate-900">
                  {shop.currency}{subtotal}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span>Delivery Charge</span>
                {deliveryFee === 0 ? (
                  <span className="text-emerald-700 font-bold uppercase text-[10px] bg-emerald-100 px-1.5 py-0.5 rounded">
                    FREE
                  </span>
                ) : (
                  <span className="font-semibold text-slate-900">
                    {shop.currency}{deliveryFee}
                  </span>
                )}
              </div>
              <div className="pt-2 border-t border-slate-100 flex justify-between text-sm font-bold text-slate-900">
                <span>Total Amount</span>
                <span className="text-emerald-800 text-base">
                  {shop.currency}{totalPayable}
                </span>
              </div>
            </div>

            <button
              id="proceed-to-checkout-btn"
              onClick={onCheckout}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-4 rounded-xl shadow-xs active:scale-[0.99] transition-all cursor-pointer text-sm"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
