import React, { useState, useRef } from 'react';
import {
  QrCode,
  Package,
  ShoppingBag,
  Settings,
  Store,
  ArrowLeft,
  Plus,
  Trash2,
  CheckCircle,
  Truck,
  Edit2,
  Save,
  Clock,
  Phone,
  MapPin,
  Upload,
  Layers,
  Barcode,
  DollarSign,
  Image as ImageIcon,
  Download,
} from 'lucide-react';
import { ShopInfo, Product, Order, OwnerTab, Category, ProductVariant } from '../types';
import { OwnerQRCodeSection } from './OwnerQRCodeSection';
import { api } from '../services/api';

interface OwnerDashboardProps {
  shop: ShopInfo;
  categories: Category[];
  products: Product[];
  orders: Order[];
  onUpdateShop: (updated: Partial<ShopInfo>) => void;
  onUpdateProducts: (products: Product[]) => void;
  onUpdateOrders: (orders: Order[]) => void;
  onUpdateCategories: (categories: Category[]) => void;
  onSwitchToCustomer: () => void;
  initialTab?: OwnerTab;
}

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({
  shop,
  categories,
  products,
  orders,
  onUpdateShop,
  onUpdateProducts,
  onUpdateOrders,
  onUpdateCategories,
  onSwitchToCustomer,
  initialTab = 'qr_code',
}) => {
  const [activeTab, setActiveTab] = useState<OwnerTab>(initialTab);

  // Settings form state (SHOP)
  const [settingsShopName, setSettingsShopName] = useState(shop.name);
  const [settingsOwnerName, setSettingsOwnerName] = useState(shop.ownerName || 'Rajesh Sharma');
  const [settingsTagline, setSettingsTagline] = useState(shop.tagline || '');
  const [settingsPhone, setSettingsPhone] = useState(shop.phone || shop.contact || '');
  const [settingsAddress, setSettingsAddress] = useState(shop.address || '');
  const [settingsShopImage, setSettingsShopImage] = useState(shop.shopImage || '');
  const [settingsDeliveryEnabled, setSettingsDeliveryEnabled] = useState(shop.deliveryEnabled !== false);
  const [settingsDeliveryPricePerKm, setSettingsDeliveryPricePerKm] = useState(String(shop.deliveryPricePerKm ?? 5));
  const [settingsDeliveryFee, setSettingsDeliveryFee] = useState(String(shop.deliveryFee ?? 25));
  const [settingsFreeAbove, setSettingsFreeAbove] = useState(String(shop.freeDeliveryAbove ?? 399));
  const [settingsUpiId, setSettingsUpiId] = useState(shop.upiId || '');

  // Wholesale settings
  const [enableWholesale, setEnableWholesale] = useState(shop.retailWholesaleSettings?.enableWholesale ?? true);
  const [wholesaleMinQty, setWholesaleMinQty] = useState(String(shop.retailWholesaleSettings?.wholesaleMinOrderQuantity ?? 10));
  const [wholesaleDiscount, setWholesaleDiscount] = useState(String(shop.retailWholesaleSettings?.wholesaleDiscountPercent ?? 12));
  const [wholesaleTermsNote, setWholesaleTermsNote] = useState(shop.retailWholesaleSettings?.wholesaleTermsNote ?? '');

  const [saveSettingsSuccess, setSaveSettingsSuccess] = useState(false);
  const [uploadingShopImage, setUploadingShopImage] = useState(false);

  // Add Product form state
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdNameHindi, setNewProdNameHindi] = useState('');
  const [newProdCategory, setNewProdCategory] = useState(categories[0]?.name || 'Groceries & Staples');
  const [newProdRetailPrice, setNewProdRetailPrice] = useState('');
  const [newProdWholesalePrice, setNewProdWholesalePrice] = useState('');
  const [newProdStock, setNewProdStock] = useState('50');
  const [newProdUnit, setNewProdUnit] = useState('1 kg');
  const [newProdBarcode, setNewProdBarcode] = useState('');
  const [newProdImage, setNewProdImage] = useState('');
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdIsVeg, setNewProdIsVeg] = useState(true);
  const [uploadingProdImage, setUploadingProdImage] = useState(false);

  // Add Category form state
  const [showAddCategoryModal, setShowAddCategoryModal] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatImage, setNewCatImage] = useState('');
  const [newCatOrder, setNewCatOrder] = useState(String(categories.length + 1));
  const [uploadingCatImage, setUploadingCatImage] = useState(false);

  const shopImageInputRef = useRef<HTMLInputElement>(null);
  const prodImageInputRef = useRef<HTMLInputElement>(null);
  const catImageInputRef = useRef<HTMLInputElement>(null);

  // Handle persistent file upload
  const handleFileUpload = async (
    file: File,
    onSuccess: (url: string) => void,
    setLoading: (l: boolean) => void
  ) => {
    setLoading(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64 = reader.result as string;
          const result = await api.uploadImage(base64, file.name);
          onSuccess(result.url);
        } catch (e) {
          alert('Failed to save image to persistent storage');
        } finally {
          setLoading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch {
      setLoading(false);
      alert('Error reading file');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const updates: Partial<ShopInfo> = {
      name: settingsShopName.trim(),
      ownerName: settingsOwnerName.trim(),
      tagline: settingsTagline.trim(),
      phone: settingsPhone.trim(),
      contact: settingsPhone.trim(),
      address: settingsAddress.trim(),
      shopImage: settingsShopImage.trim(),
      deliveryEnabled: settingsDeliveryEnabled,
      deliveryPricePerKm: Number(settingsDeliveryPricePerKm) || 0,
      deliveryFee: Number(settingsDeliveryFee) || 0,
      freeDeliveryAbove: Number(settingsFreeAbove) || 0,
      upiId: settingsUpiId.trim(),
      retailWholesaleSettings: {
        enableWholesale,
        wholesaleMinOrderQuantity: Number(wholesaleMinQty) || 1,
        wholesaleDiscountPercent: Number(wholesaleDiscount) || 0,
        wholesaleTermsNote: wholesaleTermsNote.trim(),
      },
    };

    try {
      const updated = await api.updateShop(updates);
      onUpdateShop(updated);
      setSaveSettingsSuccess(true);
      setTimeout(() => setSaveSettingsSuccess(false), 3000);
    } catch (err) {
      alert('Failed to save shop settings to backend storage');
    }
  };

  const handleToggleStock = async (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;
    const nextInStock = !prod.inStock;
    const nextStock = nextInStock ? (prod.stock > 0 ? prod.stock : 10) : 0;
    try {
      const updated = await api.updateProduct(productId, { inStock: nextInStock, stock: nextStock });
      onUpdateProducts(products.map((p) => (p.id === productId ? updated : p)));
    } catch {
      alert('Failed to update stock in persistent storage');
    }
  };

  const handleUpdatePrice = async (productId: string, newRetailPrice: number) => {
    if (isNaN(newRetailPrice) || newRetailPrice <= 0) return;
    try {
      const updated = await api.updateProduct(productId, {
        retailPrice: newRetailPrice,
        price: newRetailPrice,
      });
      onUpdateProducts(products.map((p) => (p.id === productId ? updated : p)));
    } catch {
      alert('Failed to update price in persistent storage');
    }
  };

  const handleUpdateStockCount = async (productId: string, newStock: number) => {
    if (isNaN(newStock) || newStock < 0) return;
    try {
      const updated = await api.updateProduct(productId, {
        stock: newStock,
        inStock: newStock > 0,
      });
      onUpdateProducts(products.map((p) => (p.id === productId ? updated : p)));
    } catch {
      alert('Failed to update stock count in persistent storage');
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('Are you sure you want to remove this product?')) return;
    try {
      await api.deleteProduct(productId);
      onUpdateProducts(products.filter((p) => p.id !== productId));
    } catch {
      alert('Failed to delete product from persistent storage');
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim() || !newProdRetailPrice) return;

    const retailPrice = Number(newProdRetailPrice);
    const wholesalePrice = newProdWholesalePrice ? Number(newProdWholesalePrice) : Math.round(retailPrice * 0.9);
    const stock = Number(newProdStock) || 0;

    const newProductPayload: Partial<Product> = {
      name: newProdName.trim(),
      nameHindi: newProdNameHindi.trim() || undefined,
      category: newProdCategory,
      retailPrice,
      price: retailPrice,
      wholesalePrice,
      stock,
      inStock: stock > 0,
      unit: newProdUnit.trim(),
      barcode: newProdBarcode.trim() || `${Date.now()}`,
      image:
        newProdImage.trim() ||
        'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&auto=format&fit=crop&q=80',
      images: [
        newProdImage.trim() ||
          'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&auto=format&fit=crop&q=80',
      ],
      description: newProdDesc.trim() || 'Fresh quality product from ' + shop.name,
      isVeg: newProdIsVeg,
    };

    try {
      const created = await api.createProduct(newProductPayload);
      onUpdateProducts([created, ...products]);
      setShowAddProductModal(false);
      // Reset
      setNewProdName('');
      setNewProdNameHindi('');
      setNewProdRetailPrice('');
      setNewProdWholesalePrice('');
      setNewProdStock('50');
      setNewProdUnit('1 kg');
      setNewProdBarcode('');
      setNewProdImage('');
      setNewProdDesc('');
    } catch {
      alert('Failed to save new product to persistent storage');
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    try {
      const created = await api.createCategory({
        name: newCatName.trim(),
        image: newCatImage.trim() || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=500&auto=format&fit=crop&q=80',
        displayOrder: Number(newCatOrder) || categories.length + 1,
      });
      onUpdateCategories([...categories, created]);
      setShowAddCategoryModal(false);
      setNewCatName('');
      setNewCatImage('');
      setNewCatOrder(String(categories.length + 2));
    } catch {
      alert('Failed to save category to persistent storage');
    }
  };

  const handleDeleteCategory = async (catId: string) => {
    if (!confirm('Are you sure you want to delete this category?')) return;
    try {
      await api.deleteCategory(catId);
      onUpdateCategories(categories.filter((c) => c.id !== catId));
    } catch {
      alert('Failed to delete category');
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: Order['status']) => {
    try {
      const updated = await api.updateOrderStatus(orderId, status);
      onUpdateOrders(orders.map((o) => (o.id === orderId ? updated : o)));
    } catch {
      alert('Failed to update order status in persistent storage');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Owner Header */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {shop.shopImage ? (
              <img
                src={shop.shopImage}
                alt={shop.name}
                className="w-10 h-10 rounded-xl object-cover border border-slate-700 shrink-0"
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-bold text-lg shadow-xs shrink-0">
                <Store className="w-5 h-5" />
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-white text-base sm:text-lg leading-tight">
                  {shop.name}
                </h1>
                <span className="text-[10px] uppercase font-bold tracking-wide bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded">
                  Owner Portal
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Owner: {shop.ownerName} • Contact: {shop.contact || shop.phone} • Store ID: {shop.id}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              id="owner-download-zip-link"
              href="/project.zip"
              download="apna-mart-project.zip"
              className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-medium px-3 py-2 rounded-xl text-xs sm:text-sm border border-slate-700 shadow-xs transition-colors cursor-pointer"
              title="Download entire project code as ZIP file"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">Project ZIP</span>
              <span className="sm:hidden">ZIP</span>
            </a>

            <button
              id="owner-back-to-customer-btn"
              onClick={onSwitchToCustomer}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm shadow-xs transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Customer View</span>
            </button>
          </div>
        </div>

        {/* Owner Nav Tabs */}
        <div className="max-w-7xl mx-auto px-4 flex gap-1 overflow-x-auto border-t border-slate-800/80">
          <button
            id="owner-tab-qr-code"
            onClick={() => setActiveTab('qr_code')}
            className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'qr_code'
                ? 'border-emerald-400 text-emerald-400 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Shop QR Code</span>
          </button>

          <button
            id="owner-tab-settings"
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'settings'
                ? 'border-emerald-400 text-emerald-400 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Owner Settings</span>
          </button>

          <button
            id="owner-tab-categories"
            onClick={() => setActiveTab('categories')}
            className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'categories'
                ? 'border-emerald-400 text-emerald-400 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Categories ({categories.length})</span>
          </button>

          <button
            id="owner-tab-products"
            onClick={() => setActiveTab('products')}
            className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'products'
                ? 'border-emerald-400 text-emerald-400 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Products ({products.length})</span>
          </button>

          <button
            id="owner-tab-orders"
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'orders'
                ? 'border-emerald-400 text-emerald-400 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Orders ({orders.length})</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {/* TAB 1: Shop QR Code Section */}
        {activeTab === 'qr_code' && (
          <div>
            <div className="mb-4">
              <h2 className="text-xl font-bold text-slate-900">Shop QR Code</h2>
              <p className="text-xs text-slate-500">
                Display, download, or share this unique QR code to let customers open your shop immediately.
              </p>
            </div>
            <OwnerQRCodeSection shop={shop} onUpdateShop={onUpdateShop} />
          </div>
        )}

        {/* TAB 2: Settings Section (SHOP) */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-slate-900">Shop & Owner Settings</h2>
                <p className="text-xs text-slate-500">
                  Manage persistent shop profile, delivery options, and retail/wholesale configurations.
                </p>
              </div>
            </div>

            {/* Featured Shop QR Code Quick Access inside Owner Settings */}
            <div className="bg-emerald-800 text-white rounded-2xl p-5 sm:p-6 shadow-xs border border-emerald-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center text-emerald-200 border border-white/20">
                  <QrCode className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider bg-emerald-700 px-2 py-0.5 rounded text-emerald-200">
                    Official Shop QR Code
                  </span>
                  <h3 className="text-lg font-bold text-white mt-0.5">
                    {shop.name} QR Code
                  </h3>
                  <p className="text-xs text-emerald-200/90 mt-0.5">
                    Unique shop link: <span className="font-mono text-white">{shop.id}</span>
                  </p>
                </div>
              </div>

              <button
                id="owner-settings-view-qr-btn"
                onClick={() => setActiveTab('qr_code')}
                className="flex items-center gap-2 bg-white text-emerald-900 hover:bg-emerald-50 font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-xs transition-all cursor-pointer shrink-0"
              >
                <QrCode className="w-4 h-4 text-emerald-700" />
                <span>View & Print Shop QR</span>
              </button>
            </div>

            {/* Settings Form */}
            <form onSubmit={handleSaveSettings} className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-2xs space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="font-bold text-slate-900 text-sm sm:text-base flex items-center gap-2">
                  <Store className="w-4 h-4 text-emerald-600" />
                  <span>1. Shop Identity & Contact</span>
                </h3>
                {saveSettingsSuccess && (
                  <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                    <CheckCircle className="w-3.5 h-3.5" /> Saved to Persistent Cloud Database!
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Shop Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsShopName}
                    onChange={(e) => setSettingsShopName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Owner Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsOwnerName}
                    onChange={(e) => setSettingsOwnerName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Contact Phone / WhatsApp *
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsPhone}
                    onChange={(e) => setSettingsPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Tagline / Subtitle
                  </label>
                  <input
                    type="text"
                    value={settingsTagline}
                    onChange={(e) => setSettingsTagline(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">
                    Shop Physical Address *
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsAddress}
                    onChange={(e) => setSettingsAddress(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                  />
                </div>

                {/* Shop Image / Logo with Persistent Upload */}
                <div className="md:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">
                    Shop Logo / Image (Stored Persistently)
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="text"
                      placeholder="https://... or upload image"
                      value={settingsShopImage}
                      onChange={(e) => setSettingsShopImage(e.target.value)}
                      className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                    />
                    <input
                      type="file"
                      ref={shopImageInputRef}
                      className="hidden"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          handleFileUpload(file, (url) => setSettingsShopImage(url), setUploadingShopImage);
                        }
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => shopImageInputRef.current?.click()}
                      disabled={uploadingShopImage}
                      className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs cursor-pointer shrink-0 border border-slate-300"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingShopImage ? 'Uploading...' : 'Upload Image'}</span>
                    </button>
                  </div>
                  {settingsShopImage && (
                    <div className="mt-2 flex items-center gap-2">
                      <img
                        src={settingsShopImage}
                        alt="Shop Preview"
                        className="w-12 h-12 object-cover rounded-lg border border-slate-200"
                      />
                      <span className="text-[11px] text-slate-500">Persistent image linked</span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    UPI ID (for payments)
                  </label>
                  <input
                    type="text"
                    value={settingsUpiId}
                    onChange={(e) => setSettingsUpiId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                  />
                </div>
              </div>

              {/* Delivery Settings */}
              <div className="pt-4 border-t border-slate-100">
                <h4 className="font-bold text-slate-900 text-xs sm:text-sm mb-3 flex items-center gap-2">
                  <Truck className="w-4 h-4 text-emerald-600" />
                  <span>2. Delivery Pricing & Settings</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs sm:text-sm">
                  <div className="sm:col-span-3">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settingsDeliveryEnabled}
                        onChange={(e) => setSettingsDeliveryEnabled(e.target.checked)}
                        className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                      />
                      <span className="font-semibold text-slate-800">
                        Enable Home Delivery Service
                      </span>
                    </label>
                    <p className="text-[11px] text-slate-500 ml-6">
                      When unchecked, customers can only choose Store Pickup.
                    </p>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Delivery Price per km (₹)
                    </label>
                    <input
                      type="number"
                      value={settingsDeliveryPricePerKm}
                      onChange={(e) => setSettingsDeliveryPricePerKm(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Base Delivery Fee (₹)
                    </label>
                    <input
                      type="number"
                      value={settingsDeliveryFee}
                      onChange={(e) => setSettingsDeliveryFee(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Free Delivery Above (₹)
                    </label>
                    <input
                      type="number"
                      value={settingsFreeAbove}
                      onChange={(e) => setSettingsFreeAbove(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Retail & Wholesale Settings */}
              <div className="pt-4 border-t border-slate-100">
                <h4 className="font-bold text-slate-900 text-xs sm:text-sm mb-3 flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <span>3. Retail & Wholesale Settings</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
                  <div className="sm:col-span-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={enableWholesale}
                        onChange={(e) => setEnableWholesale(e.target.checked)}
                        className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                      />
                      <span className="font-semibold text-slate-800">
                        Enable Wholesale Pricing for Bulk Orders
                      </span>
                    </label>
                    <p className="text-[11px] text-slate-500 ml-6">
                      Automatically apply wholesale prices when order quantity meets the threshold.
                    </p>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Wholesale Minimum Quantity (Units)
                    </label>
                    <input
                      type="number"
                      value={wholesaleMinQty}
                      onChange={(e) => setWholesaleMinQty(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Default Wholesale Discount (%)
                    </label>
                    <input
                      type="number"
                      value={wholesaleDiscount}
                      onChange={(e) => setWholesaleDiscount(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-slate-700 mb-1">
                      Wholesale Policy Terms & Note
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Special bulk rates for kirana stores and businesses"
                      value={wholesaleTermsNote}
                      onChange={(e) => setWholesaleTermsNote(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs sm:text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-5 py-2.5 rounded-xl shadow-xs transition-colors cursor-pointer text-xs sm:text-sm"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Shop Settings to Persistent Storage</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB 3: Categories Management */}
        {activeTab === 'categories' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-slate-900">Categories Management</h2>
                <p className="text-xs text-slate-500">
                  Manage store product categories, icons/images, and display sort order.
                </p>
              </div>

              <button
                id="owner-add-category-btn"
                onClick={() => setShowAddCategoryModal(true)}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-xs transition-all cursor-pointer self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Category</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {categories.map((cat) => (
                <div
                  key={cat.id}
                  className="bg-white rounded-2xl border border-slate-200 p-4 flex items-center gap-3.5 shadow-2xs"
                >
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-14 h-14 rounded-xl object-cover border border-slate-100 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">
                      Order: #{cat.displayOrder}
                    </span>
                    <h3 className="font-bold text-slate-900 text-sm truncate">{cat.name}</h3>
                    <p className="text-[11px] text-slate-500">
                      {products.filter((p) => p.category === cat.name).length} products
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteCategory(cat.id)}
                    className="text-slate-400 hover:text-rose-600 p-1.5 transition-colors cursor-pointer"
                    title="Delete category"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: Products Management */}
        {activeTab === 'products' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-slate-900">Product Catalog & Inventory</h2>
                <p className="text-xs text-slate-500">
                  Manage persistent products, retail & wholesale pricing, barcodes, and stock levels.
                </p>
              </div>

              <button
                id="owner-add-product-btn"
                onClick={() => setShowAddProductModal(true)}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-xs transition-all cursor-pointer self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Product</span>
              </button>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                      <th className="py-3 px-4">Product</th>
                      <th className="py-3 px-3">Category</th>
                      <th className="py-3 px-3">Retail Price ({shop.currency})</th>
                      <th className="py-3 px-3">Wholesale Price ({shop.currency})</th>
                      <th className="py-3 px-3">Stock Units</th>
                      <th className="py-3 px-3">Barcode</th>
                      <th className="py-3 px-3">Status</th>
                      <th className="py-3 px-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={p.image}
                              alt={p.name}
                              className="w-10 h-10 rounded-lg object-cover bg-slate-100 border border-slate-200 shrink-0"
                            />
                            <div>
                              <p className="font-semibold text-slate-900 leading-tight">
                                {p.name}
                              </p>
                              <p className="text-[11px] text-slate-500">
                                {p.unit} {p.nameHindi ? `• ${p.nameHindi}` : ''}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-slate-600">{p.category}</td>
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1">
                            <span>{shop.currency}</span>
                            <input
                              type="number"
                              defaultValue={p.retailPrice ?? p.price}
                              onBlur={(e) => handleUpdatePrice(p.id, Number(e.target.value))}
                              className="w-16 px-1.5 py-0.5 border border-slate-200 rounded text-xs focus:outline-none focus:border-emerald-500 font-medium"
                            />
                          </div>
                        </td>
                        <td className="py-3 px-3 text-slate-600">
                          <span className="font-semibold text-slate-800">
                            {shop.currency}{p.wholesalePrice || Math.round((p.retailPrice ?? p.price) * 0.9)}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <input
                            type="number"
                            defaultValue={p.stock}
                            onBlur={(e) => handleUpdateStockCount(p.id, Number(e.target.value))}
                            className="w-16 px-1.5 py-0.5 border border-slate-200 rounded text-xs focus:outline-none focus:border-emerald-500 font-medium"
                          />
                        </td>
                        <td className="py-3 px-3 text-slate-500 font-mono text-[11px]">
                          {p.barcode || '—'}
                        </td>
                        <td className="py-3 px-3">
                          <button
                            onClick={() => handleToggleStock(p.id)}
                            className={`px-2.5 py-1 rounded-full text-xs font-semibold cursor-pointer border transition-colors ${
                              p.inStock
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                                : 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100'
                            }`}
                          >
                            {p.inStock ? 'In Stock' : 'Out of Stock'}
                          </button>
                        </td>
                        <td className="py-3 px-3 text-right">
                          <button
                            onClick={() => handleDeleteProduct(p.id)}
                            className="text-slate-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                            title="Delete product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: Orders Management */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900">Orders Management</h2>
              <p className="text-xs text-slate-500">
                Persistent orders with frozen purchase prices and authoritative billing.
              </p>
            </div>

            <div className="space-y-3">
              {orders.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-400">
                  <ShoppingBag className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                  <p className="font-semibold text-slate-700 text-sm">No orders received yet</p>
                  <p className="text-xs text-slate-500 mt-0.5">When customers place orders, they will show up here.</p>
                </div>
              ) : (
                orders.map((o) => (
                  <div
                    key={o.id}
                    className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-2xs space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 text-xs">
                      <div>
                        <span className="font-bold text-slate-900 text-sm">{o.id}</span>
                        <span className="text-slate-500 ml-2">
                          {new Date(o.createdAt).toLocaleString([], {
                            dateStyle: 'medium',
                            timeStyle: 'short',
                          })}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500">Status:</span>
                        <select
                          value={o.status || o.orderStatus}
                          onChange={(e) =>
                            handleUpdateOrderStatus(o.id, e.target.value as Order['status'])
                          }
                          className="px-2.5 py-1 rounded-lg border border-slate-300 text-xs font-semibold bg-slate-50 cursor-pointer focus:outline-none focus:border-emerald-500"
                        >
                          <option value="pending">Pending</option>
                          <option value="accepted">Accepted</option>
                          <option value="out_for_delivery">Out for Delivery</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>

                    {/* Customer & Address Details */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <div>
                        <p className="text-slate-500">Customer Details:</p>
                        <p className="font-semibold text-slate-900">{o.customer.name} ({o.customer.phone})</p>
                        {o.customer.notes && (
                          <p className="text-slate-600 mt-1 italic">Note: "{o.customer.notes}"</p>
                        )}
                      </div>
                      <div>
                        <p className="text-slate-500">Fulfillment & Address:</p>
                        <p className="font-semibold text-slate-900">
                          {o.pickupOrDelivery === 'pickup' ? 'Store Pickup' : 'Home Delivery'} — {o.customer.address}
                        </p>
                        <p className="text-slate-600 mt-1">
                          Payment: <span className="uppercase font-semibold">{o.customer.paymentMethod}</span>
                          {o.distanceKm ? ` • Distance: ${o.distanceKm} km` : ''}
                        </p>
                      </div>
                    </div>

                    {/* Items with Frozen Snapshot Prices */}
                    <div className="text-xs space-y-1">
                      <p className="font-semibold text-slate-700">Order Items ({o.itemCount}):</p>
                      <div className="divide-y divide-slate-100">
                        {(o.orderItems && o.orderItems.length > 0
                          ? o.orderItems
                          : o.items.map((it) => ({
                              name: it.product.name,
                              unit: it.product.unit,
                              quantity: it.quantity,
                              price: it.product.retailPrice ?? it.product.price,
                              isWholesale: false,
                            }))
                        ).map((item, idx) => (
                          <div key={idx} className="py-1 flex justify-between text-slate-600">
                            <span>
                              {item.name} ({item.unit}) × {item.quantity}
                              {item.isWholesale ? ' [Wholesale Rate]' : ''}
                            </span>
                            <span className="font-semibold text-slate-900">
                              {shop.currency}{item.price * item.quantity}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Subtotal, Delivery Charge, Total */}
                    <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-1">
                      <div className="text-slate-500 flex items-center gap-3">
                        <span>Subtotal: {shop.currency}{o.subtotal}</span>
                        <span>•</span>
                        <span>Delivery Charge: {o.deliveryFee === 0 ? 'FREE' : `${shop.currency}${o.deliveryFee}`}</span>
                      </div>
                      <div className="text-xs sm:text-sm font-bold flex items-center gap-2">
                        <span className="text-slate-700">Grand Total:</span>
                        <span className="text-emerald-800 text-base">{shop.currency}{o.totalAmount || o.grandTotal}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </main>

      {/* Modal: Add New Product */}
      {showAddProductModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 border border-slate-200 shadow-xl max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-slate-900 text-base mb-3">Add New Product</h3>
            <form onSubmit={handleAddProduct} className="space-y-3 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Product Name *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Maggi 2-Minute Masala Noodles"
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Hindi / Local Name</label>
                <input
                  type="text"
                  placeholder="e.g. मैगी नूडल्स"
                  value={newProdNameHindi}
                  onChange={(e) => setNewProdNameHindi(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Retail Price (₹) *</label>
                  <input
                    required
                    type="number"
                    placeholder="14"
                    value={newProdRetailPrice}
                    onChange={(e) => setNewProdRetailPrice(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Wholesale Price (₹)</label>
                  <input
                    type="number"
                    placeholder="12"
                    value={newProdWholesalePrice}
                    onChange={(e) => setNewProdWholesalePrice(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Unit / Weight *</label>
                  <input
                    required
                    type="text"
                    placeholder="70 g pack"
                    value={newProdUnit}
                    onChange={(e) => setNewProdUnit(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Stock Quantity</label>
                  <input
                    type="number"
                    placeholder="50"
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white text-xs"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Barcode</label>
                  <input
                    type="text"
                    placeholder="8901..."
                    value={newProdBarcode}
                    onChange={(e) => setNewProdBarcode(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Product Image with Persistent Upload */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Product Image</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="https://... or upload"
                    value={newProdImage}
                    onChange={(e) => setNewProdImage(e.target.value)}
                    className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                  <input
                    type="file"
                    ref={prodImageInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        handleFileUpload(file, (url) => setNewProdImage(url), setUploadingProdImage);
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => prodImageInputRef.current?.click()}
                    disabled={uploadingProdImage}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs cursor-pointer border border-slate-300 shrink-0 flex items-center gap-1"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingProdImage ? '...' : 'Upload'}</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Fresh quality item from store"
                  value={newProdDesc}
                  onChange={(e) => setNewProdDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddProductModal(false)}
                  className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs cursor-pointer"
                >
                  Save Product to Cloud
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add New Category */}
      {showAddCategoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 border border-slate-200 shadow-xl">
            <h3 className="font-bold text-slate-900 text-base mb-3">Add New Category</h3>
            <form onSubmit={handleAddCategory} className="space-y-3 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Category Name *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Frozen Foods & Desserts"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Display Sort Order</label>
                <input
                  type="number"
                  value={newCatOrder}
                  onChange={(e) => setNewCatOrder(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Category Image</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="https://... or upload"
                    value={newCatImage}
                    onChange={(e) => setNewCatImage(e.target.value)}
                    className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                  <input
                    type="file"
                    ref={catImageInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        handleFileUpload(file, (url) => setNewCatImage(url), setUploadingCatImage);
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => catImageInputRef.current?.click()}
                    disabled={uploadingCatImage}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs cursor-pointer border border-slate-300 shrink-0 flex items-center gap-1"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingCatImage ? '...' : 'Upload'}</span>
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddCategoryModal(false)}
                  className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs cursor-pointer"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
